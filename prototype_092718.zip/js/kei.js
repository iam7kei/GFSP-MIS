function changeEditBtn{
    document.getElementById("schedule-modal-edit-btn").value = 'Save';
}